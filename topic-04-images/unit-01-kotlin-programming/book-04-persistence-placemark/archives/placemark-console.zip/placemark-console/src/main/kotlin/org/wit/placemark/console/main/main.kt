package org.wit.placemark.console.main

import org.wit.placemark.console.controllers.PlacemarkController

fun main(args: Array<String>) {
    PlacemarkController().start()
}




