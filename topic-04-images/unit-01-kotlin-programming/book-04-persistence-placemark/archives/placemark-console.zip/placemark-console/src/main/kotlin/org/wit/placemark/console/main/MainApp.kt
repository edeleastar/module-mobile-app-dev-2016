package org.wit.placemark.console.main

import org.wit.placemark.console.views.MenuScreen
import tornadofx.App

class MainApp : App(MenuScreen::class)