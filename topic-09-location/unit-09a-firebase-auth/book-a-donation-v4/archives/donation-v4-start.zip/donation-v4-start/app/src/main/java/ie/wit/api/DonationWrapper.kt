package ie.wit.api

import ie.wit.models.DonationModel

class DonationWrapper {
    var message: String? = null
    var data: DonationModel? = null
}