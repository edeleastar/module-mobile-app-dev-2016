package ie.wit.tests

import ie.wit.utils.doSomethingUsefulOne
import ie.wit.utils.doSomethingUsefulTwo
import kotlinx.coroutines.runBlocking

fun test1() {
    runBlocking {
        val one = doSomethingUsefulOne()
        val two = doSomethingUsefulTwo()
        println("The answer is ${one + two}")
    }
}