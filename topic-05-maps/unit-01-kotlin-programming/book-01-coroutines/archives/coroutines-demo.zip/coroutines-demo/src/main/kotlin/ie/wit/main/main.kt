package ie.wit.main

import ie.wit.tests.*
import kotlin.system.measureTimeMillis

fun main() {
    println("Kotlin Coroutines Demo App")

    val time = measureTimeMillis {
        test5()
    }
    println("\nCompleted in $time ms")
}
