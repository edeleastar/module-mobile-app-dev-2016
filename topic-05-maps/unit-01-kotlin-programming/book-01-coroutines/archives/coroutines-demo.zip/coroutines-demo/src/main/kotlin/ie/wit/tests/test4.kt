package ie.wit.tests

import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

fun test4() {
    GlobalScope.launch {  // launch new coroutine in background and continue

        delay(3000L) // non-blocking delay for 3 seconds (default time unit is ms)
        println("World!") // print after delay
        val sum1 = async { // non blocking sum1
            delay(2000L)
            println("sum1 paused in the background!")
            2 + 2
        }
        val sum2 = async { // non blocking sum2
            delay(1000L)
            println("sum2 paused in the background!")
            3 + 3
        }
        println("waiting for concurrent sums")
        val total = sum1.await() + sum2.await() // execution stops until both sums are calculated
        println("Total is: $total")
    }
    println("Hello,")     // main thread continues while coroutine executes
    Thread.sleep(3000L)   // block main thread for 6 seconds to keep JVM alive
}