package ie.wit.tests

import ie.wit.utils.wikipedia
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

fun test5() {
    val keyword = "Triathlon"
    GlobalScope.launch {  // launch new coroutine in background and continue
        delay(2000L) // non-blocking delay for 2 seconds (default time unit is ms)
        println("World!") // print after delay
        val wResult = async { wikipedia(keyword) }
        println("Wikipedia replied: ${wResult.await()}")
    }
    println("Hello,")     // main thread continues while coroutine executes
    Thread.sleep(3000L)   // block main thread for 3 seconds to keep JVM alive
}