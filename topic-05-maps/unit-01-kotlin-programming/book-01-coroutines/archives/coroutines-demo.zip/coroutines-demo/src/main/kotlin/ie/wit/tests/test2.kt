package ie.wit.tests

import ie.wit.utils.doSomethingUsefulOne
import ie.wit.utils.doSomethingUsefulTwo
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking

fun test2() {
    runBlocking {
        val one = async { doSomethingUsefulOne() }
        val two = async { doSomethingUsefulTwo() }
        println("The answer is ${one.await() + two.await()}")
    }
}