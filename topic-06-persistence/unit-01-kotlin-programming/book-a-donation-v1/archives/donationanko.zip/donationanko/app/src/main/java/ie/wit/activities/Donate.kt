package ie.wit.activities

import android.content.Intent
import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import ie.wit.R
import ie.wit.main.DonationApp
import ie.wit.models.DonationModel

import kotlinx.android.synthetic.main.activity_donate.*
import kotlinx.android.synthetic.main.content_donate.*
import org.jetbrains.anko.*

import org.jetbrains.anko.design.snackbar

class Donate : AppCompatActivity() {

    lateinit var app: DonationApp
    var totalDonated = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_donate)
        setSupportActionBar(toolbar)

        fab.setOnClickListener { view ->
            view.snackbar("Replace with your own action", "Action") { alertAnkoDemo() }
        }


        app = this.application as DonationApp

        progressBar.max = 10000
        amountPicker.minValue = 1
        amountPicker.maxValue = 1000

        amountPicker.setOnValueChangedListener { picker, oldVal, newVal ->
            //Display the newly selected number to paymentAmount
            paymentAmount.setText("$newVal")
        }

        donateButton.setOnClickListener {
            val amount = if (paymentAmount.text.isNotEmpty())
                 paymentAmount.text.toString().toInt() else amountPicker.value
            if(totalDonated >= progressBar.max)
                toast("Donation Amount Exceeded!")
            else {
                val paymentmethod = if(paymentMethod.checkedRadioButtonId == R.id.Direct) "Direct" else "Paypal"
                totalDonated += amount
                totalSoFar.text = "$$totalDonated"
                progressBar.progress = totalDonated
                app.donationsStore.create(DonationModel(paymentmethod = paymentmethod,amount = amount))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        totalDonated = app.donationsStore.findAll().sumBy { it.amount }
        progressBar.progress = totalDonated
        totalSoFar.text = "$$totalDonated"
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_donate, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_report -> {
                startActivity<Report>()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    fun alertDemo()
    {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Androidly Alert")
        builder.setMessage("This is a message")

        builder.setPositiveButton(android.R.string.yes) { dialog, which ->
            Toast.makeText(applicationContext,
                android.R.string.yes, Toast.LENGTH_SHORT).show()
        }

        builder.setNegativeButton(android.R.string.no) { dialog, which ->
            Toast.makeText(applicationContext,
                android.R.string.no, Toast.LENGTH_SHORT).show()
        }

        builder.setNeutralButton("Maybe") { dialog, which ->
            Toast.makeText(applicationContext,
                "Maybe", Toast.LENGTH_SHORT).show()
        }
        builder.show()

    }

    fun alertAnkoDemo()
    {
        alert("This is a message", "Androidly Alert") {
            yesButton { toast(android.R.string.yes) }
            noButton {toast(android.R.string.no)}
            neutralPressed("Maybe") {toast("Maybe")}
        }.show()
    }
}
